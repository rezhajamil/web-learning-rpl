
<?php $__env->startSection('content'); ?>
<div class="flex h-screen bg-gray-50 dark:bg-gray-900" :class="{ 'overflow-hidden': isSideMenuOpen }">
    <?php echo $__env->make('components.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.user.sidebar_mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex flex-col flex-1 w-full">
        <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
        <main class="h-full overflow-y-auto">
            <div class="container grid px-6 mx-auto my-3 gap-y-4">
                <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                    <?php echo e($title); ?>

                </h2>
                <?php if($subject->lesson_id): ?>
                <div class="min-w-0 p-4 bg-white rounded-lg shadow-lg dark:bg-gray-800">
                    <h4 class="mb-3 text-lg font-semibold text-purple-600 dark:text-gray-300">
                        Materi
                    </h4>
                    <div class="mb-6 text-gray-600 dark:text-gray-400">
                        <?php echo $subject->lesson->desc; ?>

                    </div>
                </div>
                <?php endif; ?>
                <?php if($subject->example_id): ?>
                <div class="min-w-0 p-4 bg-white rounded-lg shadow-lg dark:bg-gray-800">
                    <h4 class="mb-3 text-lg font-semibold text-purple-600 dark:text-gray-300">
                        Contoh
                    </h4>
                    <div class="mb-6 text-gray-600 dark:text-gray-400">
                        <?php echo $subject->example->desc; ?>

                    </div>
                    <a href="<?php echo e(asset('storage/'.$subject->example->file)); ?>" class="flex flex-col w-1/2 px-3 py-2 mt-auto transition-all border rounded-md md:w-1/6 group hover:bg-indigo-600 border-slate-600">
                        <span class="text-base font-bold truncate transition-all text-slate-600 group-hover:text-white"><?php echo e($subject->example->file_name); ?></span>
                        <span class="block mb-2 text-sm transition-all md:mb-4 font-base text-slate-600 group-hover:text-white"><?php echo e($subject->example->file_extension); ?></span>
                        <span class="text-sm font-semibold transition-all text-slate-600 group-hover:text-white">Open<i class="ml-1 font-semibold bi bi-arrow-bar-right"></i></span>
                    </a>
                </div>
                <?php endif; ?>
                <?php if($subject->quiz_id): ?>
                <div class="min-w-0 p-4 bg-purple-600 rounded-lg shadow-lg dark:bg-gray-800">
                    <h4 class="mb-3 text-lg font-semibold text-white dark:text-gray-300">
                        Tugas
                    </h4>
                    <div class="mb-6 text-white dark:text-gray-400">
                        <?php echo $subject->quiz->desc; ?>

                    </div>
                    <div class="flex items-end justify-between">
                        <a href="<?php echo e(asset('storage/'.$subject->quiz->file)); ?>" class="flex flex-col w-1/2 px-3 py-2 mt-auto transition-all bg-white border rounded-md md:w-1/6 group hover:bg-slate-600 border-slate-600">
                            <span class="text-base font-bold truncate transition-all text-slate-600 group-hover:text-white"><?php echo e($subject->quiz->file_name); ?></span>
                            <span class="block mb-2 text-sm transition-all md:mb-4 font-base text-slate-600 group-hover:text-white"><?php echo e($subject->quiz->file_extension); ?></span>
                            <span class="text-sm font-semibold transition-all text-slate-600 group-hover:text-white">Open<i class="ml-1 font-semibold bi bi-arrow-bar-right"></i></span>
                        </a>
                        <div class="flex flex-col w-1/2 px-3 gap-y-2 md:w-1/6">
                            <span class="block mt-auto text-sm font-bold text-white md:text-base"><i class="mr-2 bi bi-bell-fill"></i><?php echo e(date('d/m/Y H:i',strtotime($subject->quiz->deadline))); ?></span>

                            <?php if(!$answer): ?>
                            <a href="<?php echo e(route('user.quiz_answer.create',['quiz_id'=>$subject->quiz_id])); ?>" class="p-2 font-semibold text-center text-purple-800 transition bg-white rounded-lg hover:bg-slate-600 hover:text-white">Kumpul Tugas</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if($answer): ?>
                    <hr class="my-3">
                    <h4 class="mb-3 text-lg font-semibold text-white dark:text-gray-300">
                        Jawaban
                        <a href="<?php echo e(route('user.quiz_answer.edit',$answer->id)); ?>">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        <span class="block text-sm text-white"><?php echo e($answer->updated_at->format('d/m/y H:i')); ?></span>
                    </h4>
                    <div class="mb-6 text-white dark:text-gray-400">
                        <?php echo $answer->desc; ?>

                    </div>
                    <div class="flex items-end justify-between">
                        <a href="<?php echo e(asset('storage/'.$answer->file)); ?>" class="flex flex-col w-1/2 px-3 py-2 mt-auto transition-all bg-white border rounded-md md:w-1/6 group hover:bg-slate-600 border-slate-600">
                            <span class="text-base font-bold truncate transition-all text-slate-600 group-hover:text-white"><?php echo e($answer->file_name); ?></span>
                            <span class="block mb-2 text-sm transition-all md:mb-4 font-base text-slate-600 group-hover:text-white"><?php echo e($answer->file_extension); ?></span>
                            <span class="text-sm font-semibold transition-all text-slate-600 group-hover:text-white">Open<i class="ml-1 font-semibold bi bi-arrow-bar-right"></i></span>
                        </a>
                        <span class="inline-block mr-5 text-xl font-bold text-white">Nilai : <?php echo e($answer->point); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <?php if($subject->other_id): ?>
                <div class="min-w-0 p-4 bg-white rounded-lg shadow-lg dark:bg-gray-800">
                    <h4 class="mb-3 text-lg font-semibold text-purple-600 dark:text-gray-300">
                        Lainnya
                    </h4>
                    <div class="mb-6 text-gray-600 dark:text-gray-400">
                        <?php echo $subject->other->desc; ?>

                        </p>
                        <a href="<?php echo e(asset('storage/'.$subject->other->file)); ?>" class="flex flex-col w-1/2 px-3 py-2 mt-auto transition-all border rounded-md md:w-1/6 group hover:bg-indigo-600 border-slate-600">
                            <span class="text-base font-bold truncate transition-all text-slate-600 group-hover:text-white"><?php echo e($subject->other->file_name); ?></span>
                            <span class="block mb-2 text-sm transition-all md:mb-4 font-base text-slate-600 group-hover:text-white"><?php echo e($subject->other->file_extension); ?></span>
                            <span class="text-sm font-semibold transition-all text-slate-600 group-hover:text-white">Open<i class="ml-1 font-semibold bi bi-arrow-bar-right"></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acer\OneDrive\Dokumen\Web Project\Laravel 8\freelance\web-learning-rpl\web-learning-rpl\resources\views/user/subject/show.blade.php ENDPATH**/ ?>