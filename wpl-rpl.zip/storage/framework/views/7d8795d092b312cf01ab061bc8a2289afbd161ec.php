
<?php $__env->startSection('content'); ?>
<div class="flex h-screen bg-gray-50 dark:bg-gray-900" :class="{ 'overflow-hidden': isSideMenuOpen }">
    <?php echo $__env->make('components.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.user.sidebar_mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex flex-col flex-1 w-full">
        <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
        <main class="h-full overflow-y-auto">
            <div class="container grid px-6 mx-auto my-3 gap-y-4">
                <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                    <?php echo e($title); ?>

                </h2>

                <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Cards -->
                <div class="min-w-0 p-4 bg-white rounded-lg shadow-lg dark:bg-gray-800">
                    <div class="flex justify-between">
                        <div class="mb-4">
                            <h4 class="mb-1 text-lg font-semibold text-purple-600 dark:text-gray-300">
                                <?php echo e($answer->user->name); ?>

                            </h4>
                            <p class="text-sm text-gray-600"><?php echo e($answer->user->email); ?></p>
                        </div>
                        <div class="flex gap-x-2">
                            <?php if($answer->updated_at<$answer->quiz->deadline): ?>
                                <span class="px-2 py-1 font-semibold leading-tight text-green-700 bg-green-100 rounded-full h-fit dark:bg-green-700 dark:text-green-100">
                                    Tepat Waktu
                                </span>
                                <?php else: ?>
                                <span class="px-2 py-1 font-semibold leading-tight text-red-700 bg-red-100 rounded-full h-fit dark:text-red-100 dark:bg-red-700">
                                    Terlambat
                                </span>
                                <?php endif; ?>
                                <span class="font-semibold text-slate-800"><?php echo e($answer->updated_at->format('d/m/Y H:i')); ?></span>
                        </div>
                    </div>
                    <div class="mb-6 text-gray-600 dark:text-gray-400">
                        <?php echo $answer->desc; ?>

                    </div>
                    <div class="flex items-end justify-between">
                        <a href="<?php echo e(asset('storage/'.$answer->file)); ?>" class="flex flex-col w-1/2 px-3 py-2 mt-auto transition-all border rounded-md md:w-1/6 group hover:bg-indigo-600 border-slate-600">
                            <span class="text-base font-bold truncate transition-all text-slate-600 group-hover:text-white"><?php echo e($answer->file_name); ?></span>
                            <span class="block mb-2 text-sm transition-all md:mb-4 font-base text-slate-600 group-hover:text-white"><?php echo e($answer->file_extension); ?></span>
                            <span class="text-sm font-semibold transition-all text-slate-600 group-hover:text-white">Open<i class="ml-1 font-semibold bi bi-arrow-bar-right"></i></span>
                        </a>
                        <form action="<?php echo e(route('admin.point',$answer->id)); ?>" method="post" class="flex gap-x-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <input type="number" class="w-1/2 form-input" name="point" id="point" placeholder="Beri Nilai" required value="<?php echo e(old('point',$answer->point)); ?>">

                            <?php $__errorArgs = ['point'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-xs text-red-600 dark:text-red-400">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button type="submit" class="inline-block px-6 py-2 font-bold text-white transition-all bg-purple-600 rounded hover:bg-purple-800">Simpan Nilai</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acer\OneDrive\Dokumen\Web Project\Laravel 8\freelance\web-learning-rpl\web-learning-rpl\resources\views/admin/quiz/answer.blade.php ENDPATH**/ ?>