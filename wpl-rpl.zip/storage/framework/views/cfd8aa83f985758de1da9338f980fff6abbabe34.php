<!DOCTYPE html>
<html :class="{ 'theme-dark': dark }" x-data="data()" lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Web Pembelajaran Learning Pemrograman Dasar XI RPL 1</title>
</head>
<body>
    <style>
        trix-toolbar [data-trix-button-group="file-tools"] {
            display: none;
        }

    </style>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>

    <script>
        document.addEventListener('trix-file-accept', function(event) {
            event.preventDefault();
        });

    </script>
</body>
</html>
<?php /**PATH C:\Users\acer\OneDrive\Dokumen\Web Project\Laravel 8\freelance\web-learning-rpl\web-learning-rpl\resources\views/layouts/app.blade.php ENDPATH**/ ?>