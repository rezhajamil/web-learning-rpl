<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
<link rel="stylesheet" href="/css/app.css" />
<link rel="stylesheet" href="/css/trix.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@animxyz/core">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="/js/app.js"></script>
<script src="/js/init-alpine.js"></script>
<script src="/js/trix.js"></script>
<?php /**PATH C:\Users\acer\OneDrive\Dokumen\Web Project\Laravel 8\freelance\web-learning-rpl\web-learning-rpl\resources\views/layouts/header.blade.php ENDPATH**/ ?>