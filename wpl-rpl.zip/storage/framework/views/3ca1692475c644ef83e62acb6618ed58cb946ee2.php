
<?php $__env->startSection('content'); ?>
<div class="flex h-screen bg-gray-50 dark:bg-gray-900" :class="{ 'overflow-hidden': isSideMenuOpen }">
    <?php echo $__env->make('components.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.user.sidebar_mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="flex flex-col flex-1 w-full">
        <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, []); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
        <main class="h-full overflow-y-auto">
            <div class="container grid px-6 mx-auto my-3 gap-y-4">
                <a href="<?php echo e(url()->previous()); ?>" class="px-3 py-2 font-semibold text-white bg-indigo-600 rounded w-fit"><i class="bi bi-arrow-left"></i> Kembali</a>
                <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
                    <?php echo e($title); ?>

                </h2>
                <form method="post" action="<?php echo e(route('admin.example.store')); ?>" class="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="subject_id" value="<?php echo e($subject); ?>">
                    <label class="block text-sm">
                        <span class="block mb-3 font-semibold text-gray-700 dark:text-gray-400">
                            Deskripsi
                        </span>
                    </label>
                    <input id="desc" type="hidden" name="desc">
                    <trix-editor input="desc"><?php echo old('desc'); ?></trix-editor>
                    <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-xs text-red-600 dark:text-red-400">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="block mt-3 mb-2 text-sm" for="file">
                        <span class="block mb-3 font-semibold text-gray-700 dark:text-gray-400">
                            File*
                        </span>
                        <span class="px-3 py-2 font-semibold text-white transition bg-purple-600 hover:bg-purple-800"><i class="mr-2 bi bi-cloud-arrow-up-fill"></i>Upload File</span>
                    </label>
                    <span class="text-neutral-900 file-preview"></span>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-xs text-red-600 dark:text-red-400">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="file" class="absolute block opacity-0 -z-10" name="file" id="file" required onchange="previewFile()">
                    <button type="submit" class="block px-3 py-2 my-3 font-semibold text-white transition bg-indigo-600 rounded hover:bg-indigo-800">Kirim</button>
                </form>
            </div>
        </main>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function previewFile() {
            const input = document.querySelector('input[name=file]');
            const preview = document.querySelector('.file-preview');
            const file = input.files[0];

            preview.innerHTML = `File Chosen: ${file.name}`;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acer\OneDrive\Dokumen\Web Project\Laravel 8\freelance\web-learning-rpl\web-learning-rpl\resources\views/admin/example/create.blade.php ENDPATH**/ ?>